# BOR-EL BudgetApp

En simpel React/Next.js app til at beregne overskud ud fra timepris, timer og faste udgifter.